﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace MODBUS_TEST_2
{
    class DBHelper
    {
        public static string uid = "sa";
        public static string password = "hntadmin";
        public static string database = "sf_jffab";
        public static string server = "118.39.27.73";
        public static string port = "3308";
        public static string connectionString = $"Server={server};Port={port};Database={database};Uid={uid};Pwd={password};";


        MySqlConnection conn = new MySqlConnection(connectionString);
        MySqlCommand cmd = new MySqlCommand();

        public void Connect()
        {
            try
            {
                conn.Open();
                Console.WriteLine("데이터베이스 연결이 성공적으로 열렸습니다.");
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"{DateTime.Now} " + ex);
            }
        }

        public void Disconnect()
        {
            try
            {
                if (conn.State == System.Data.ConnectionState.Open)
                {
                    conn.Close();
                    Console.WriteLine("데이터베이스 연결이 성공적으로 닫혔습니다.");
                }
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"{DateTime.Now} " + ex);
            }
        }
        public void insertCount(int count)
        {
            cmd.Connection = conn;
            cmd.CommandText = $"INSERT INTO product_output_log VALUES('JF-Pro-001',{count},NOW());";
            cmd.Parameters.Clear();

            try
            {
                Connect();
                cmd.ExecuteNonQuery();
                Console.WriteLine("데이터가 성공적으로 삽입되었습니다.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{DateTime.Now} 데이터 삽입 오류: {ex.Message}");
            }
            finally
            {
                Disconnect();
            }
        }

        public int[] CountSelect()
        {
            cmd.Connection = conn;
            cmd.CommandText = "SELECT COUNT(*) AS COUNT, OUTPUT_TYPE " +
                                "FROM product_output_log " +
                               "WHERE DATE(EVENT_TIME) = DATE(NOW()) " +
                               "GROUP BY OUTPUT_TYPE ";
            int[] count = new int[7];

            try
            {
                Connect();

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int outputType = reader.GetInt32("OUTPUT_TYPE");
                        int countValue = reader.GetInt32("COUNT");

                        count[outputType - 1] = countValue;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{DateTime.Now} 데이터 조회 오류: {ex.Message}");
            }
            finally
            {
                Disconnect();
            }

            return count;
        }
    }
}
