﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using System.Diagnostics;
using System.Threading;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Reflection;
using MySqlX.XDevAPI.Common;

namespace MODBUS_TEST_2
{
    public partial class Sensor2 : Form
    {
        // USR이 서버, PC가 USR로 접속
        Socket Sensor_Sock;
        AsyncObject obj = new AsyncObject(99999);   // 소켓 크기 설정
        private bool reconnecting = false;
        private readonly object lockObject = new object();
        public List<float> temValues = new List<float>();
        private int reconnectAttempts = 0;
        private const int maxReconnectAttempts = 5;
        private const int reconnectDelay = 5000; // 5초 지연 후 재연결 시도
        private string serverIp = "10.10.61.111";
        private int port = 8899;
        public Sensor2()
        {
            InitializeComponent();
            SocketSet();
            ConnServer();
        }

        private void SocketSet()
        {
            Sensor_Sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        }

        private void ConnServer()
        {
            string serverip = serverIp;
            int serverport = port;

            try
            {
                if (Sensor_Sock != null && Sensor_Sock.Connected)
                {
                    Sensor_Sock.Shutdown(SocketShutdown.Both);
                    Sensor_Sock.Close();
                }

                IPAddress serverAddr = IPAddress.Parse($"{serverip}");
                IPEndPoint clientEP = new IPEndPoint(serverAddr, serverport);
                Sensor_Sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                Sensor_Sock.BeginConnect(clientEP, new AsyncCallback(ConnectCallback), Sensor_Sock);
                Log($"Sen 1 서버 {serverip}:{serverport}에 연결 시도 중");
            }
            catch (Exception ex)
            {
                Log($"Sen 1 연결 오류: {ex}");
                Reconnect();
            }
            finally
            {
                timer1.Enabled = true;
                timer2.Enabled = true;
            }
        }

        void ConnectCallback(IAsyncResult ar)
        {
            try
            {
                Socket client = (Socket)ar.AsyncState;
                if (client == null)
                {
                    Log("Sen 1 소켓이 null입니다.");
                    Reconnect();
                    return;
                }

                if (!client.Connected)
                {
                    Log("Sen 1 소켓이 연결되지 않았습니다.");
                    Reconnect();
                    return;
                }

                client.EndConnect(ar);

                if (client.Connected)
                {
                    obj.WorkingSocket = Sensor_Sock;
                    Log("Sen 1 서버에 연결됨.");
                    Sensor_Sock.BeginReceive(obj.Buffer, 0, obj.BufferSize, 0, DataReceived, obj);
                }
                else
                {
                    Log("Sen 1 서버에 연결 실패.");
                    Reconnect();
                }
            }
            catch (SocketException ex)
            {
                Log($"Sen 1 ConnectCallback 오류: {ex.Message}");
                Reconnect();
            }
            catch (ObjectDisposedException ex)
            {
                Log($"Sen 1 ConnectCallback 오류: {ex.Message}");
                Reconnect();
            }
            catch (Exception ex)
            {
                Log($"Sen 1 예기치 않은 ConnectCallback 오류: {ex}");
                Reconnect();
            }
        }

        public class AsyncObject
        {
            public byte[] Buffer;
            public Socket WorkingSocket;
            public readonly int BufferSize;

            public AsyncObject(int bufferSize)
            {
                BufferSize = bufferSize;
                Buffer = new byte[BufferSize];
            }

            public void ClearBuffer()
            {
                Array.Clear(Buffer, 0, BufferSize);
            }
        }

        void DataReceived(IAsyncResult ar)
        {
            try
            {
                AsyncObject obj = (AsyncObject)ar.AsyncState;

                // 소켓 연결 상태 확인
                if (obj.WorkingSocket == null || !obj.WorkingSocket.Connected)
                {
                    Log("Sen 1 소켓이 연결되지 않았습니다.");
                    Reconnect(); // 연결되지 않았다면 재연결 시도
                    return;
                }

                int received = obj.WorkingSocket.EndReceive(ar);
                byte[] buffer = new byte[received];
                Array.Copy(obj.Buffer, 0, buffer, 0, received);

                Log($"Sen 1 데이터 받음 - 수신된 데이터: {received}, 버퍼: {BitConverter.ToString(buffer)}");
                ProcessData(buffer);

                Log($"Sen 1 데이터수신 완료.");

                obj.WorkingSocket.BeginReceive(obj.Buffer, 0, obj.BufferSize, 0, DataReceived, obj);
            }
            catch (ObjectDisposedException)
            {
                // 소켓이 폐기되었음, 아무것도 수행하지 않거나 이벤트를 로깅합니다.
                Log("Sen 1 소켓이 폐기되었습니다.");
            }
            catch (Exception ex)
            {
                Log($"Sen 1 DataReceived 오류: {ex}");
                Reconnect();
            }
        }

        private void Reconnect()
        {
            lock (lockObject)
            {
                if (reconnecting || reconnectAttempts >= maxReconnectAttempts)
                {
                    Log("Sen 1 최대 재연결 시도 횟수에 도달했거나 이미 재연결 중입니다.");
                    return;
                }

                reconnecting = true;
                reconnectAttempts++;
                Log($"Sen 1 재연결 중... 시도 #{reconnectAttempts}");

                try
                {
                    if (Sensor_Sock != null)
                    {
                        Sensor_Sock.Close();
                        Sensor_Sock = null;
                    }

                    // 새 소켓 생성
                    SocketSet();
                    Thread.Sleep(reconnectDelay); // 재연결 전 지연 추가
                    ConnServer();
                }
                catch (Exception ex)
                {
                    Log($"Sen 1 재연결 오류: {ex}");
                }
                finally
                {
                    reconnecting = false;
                }
            }
        }

        public byte[] HexToByte(string strHex)
        {
            byte[] bytes = new byte[strHex.Length / 2];
            for (int count = 0; count < strHex.Length; count += 2)
            {
                bytes[count / 2] = Convert.ToByte(strHex.Substring(count, 2), 16);
            }
            return bytes;
        }

        public string ByteToHex(byte[] hex)
        {
            StringBuilder result = new StringBuilder(hex.Length * 2);
            foreach (byte b in hex)
            {
                result.Append(b.ToString("x2").ToUpper());
            }
            return result.ToString();
        }

        public string ConvertBufferToString(string msg)
        {
            Log($"Sen 1 데이터 수신: {msg}");

            if (msg == null || msg.Length < 34)
            {
                throw new ArgumentOutOfRangeException(nameof(msg), "Sen 1 입력 문자열이 너무 짧습니다.");
            }
            if (msg.Length > 34)
            {
                throw new ArgumentOutOfRangeException(nameof(msg), "Sen 1 입력 문자열이 깁니다.");
            }
            string con = msg.Substring(6, 24);
            Log($"msg 변환 : {con}");
            return con;
        }

        public float HextoFloat(string num)
        {
            int intRep = int.Parse(num, NumberStyles.AllowHexSpecifier); // 16진수 문자열을 정수로 파싱
            float f = intRep;// 실제 값으로 변환하기 위해 10으로 나누기
            return f;
        }
        public List<string> SplitString(string str)
        {
            List<string> result = new List<string>();
            for (int i = 0; i < str.Length / 4; i++)
            {
                result.Add(str.Substring(i * 4, 4));
                Log($"{result[i]}");
            }
            return result;
        }
        /*측정 값의 최대 최소 범위 같이 입력*/
        public float ConvertElecToTem(float value, float min, float max)
        {
            float sub = max - min;
            float result = (value - 4.0f) / 16.0f * sub + min;
            return result;
        }
        public float ConvertVoltToTem(float value, float min, float max)
        {
            float sub = max - min;
            float result = (value - 1.0f) / 4.0f * sub + min;
            return result;
        }
        void ProcessData(byte[] buffer)
        {
            List<string> responseMsg = SplitString(ConvertBufferToString(ByteToHex(buffer)));
            int i = 0;
            foreach (var str in responseMsg)
            {
                temValues.Add(ConvertElecToTem(20, 100, 255));
                Log($"{temValues[i]}");
                i++;
            }
        }


        private static ushort CalculateCRC(byte[] data, int length)
        {
            ushort crc = 0xFFFF;
            for (int i = 0; i < length; i++)
            {
                crc ^= (ushort)(data[i] & 0xFF);

                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 0x0001) != 0)
                    {
                        crc >>= 1;
                        crc ^= 0xA001;
                    }
                    else
                    {
                        crc >>= 1;
                    }
                }
            }
            return crc;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            // 소켓 연결 상태 확인
            if (Sensor_Sock == null || !Sensor_Sock.Connected)
            {
                Log("타이머가 동작 중인데 소켓이 연결되지 않았습니다. 재연결 시도.");
                Reconnect();
                return;
            }

            // 데이터 전송을 위한 바이트 배열 정의
            List<byte[]> sendDataList = new List<byte[]>
             {
               new byte[] { 0x01, 0x04, 0x00, 0x00, 0x00, 0x04}
            };
            foreach (var sendData in sendDataList)
            {
                // CRC 계산
                ushort crc = CalculateCRC(sendData, sendData.Length);
                byte crcLow = (byte)(crc & 0xFF);
                byte crcHigh = (byte)((crc >> 8) & 0xFF);

                // CRC를 추가한 전송용 데이터 배열 생성
                byte[] sendDataWithCRC = new byte[sendData.Length + 2];
                Array.Copy(sendData, 0, sendDataWithCRC, 0, sendData.Length);
                sendDataWithCRC[sendData.Length] = crcLow;
                sendDataWithCRC[sendData.Length + 1] = crcHigh;

                // 변환된 데이터 로그 출력
                string sendDataString = BitConverter.ToString(sendDataWithCRC);
                Log($"변환 데이터01: {sendDataString}");

                try
                {
                    // 데이터 전송
                    Sensor_Sock.Send(sendDataWithCRC);

                    // 데이터 수신 대기
                    Sensor_Sock.BeginReceive(obj.Buffer, 0, obj.BufferSize, 0, DataReceived, obj);
                    Thread.Sleep(200);
                }
                catch (Exception ex)
                {
                    // 예외 처리
                    Log($"데이터 전송 오류: {ex}");
                    Reconnect();
                }
                finally
                {
                    // 타이머1 활성화
                    timer1.Enabled = true;
                }
            }
        }


        private void Log(string message)
        {
            // 디버그 출력 (파일이나 다른 목적지에 로그 기록)
            Debug.WriteLine($"{DateTime.Now}: {message}");
        }

        private void Sensor2_Load(object sender, EventArgs e)
        {

        }
    }
}
