﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Reflection;

namespace MODBUS_TEST_2
{
    public partial class Sensor3 : Form
    {
        // E-870 PC가 서버, 장치에서 서버로 접속
        // 포트를 열어 연결을 받음
        private TcpListener _listener;
        private CancellationTokenSource _cancellationTokenSource;
        private CancellationTokenSource _clientCancellationTokenSource;

        private Task _listenTask;
        private bool _isListening;
        private bool _isClientConnected;
        public int totalCount;
        public List<TextBox> TxBoxList = new List<TextBox>();
        private System.Threading.Timer _timer;
        public BizContent buttonContent;
        private const int timeout = 10000; // 5초
        private TcpClient _client; // 클라이언트 연결을 저장하기 위한 필드

        public Sensor3()
        {
            totalCount = 0;
            InitializeComponent();
            StartListening();
            TxBoxList.Add(Tx_Count_5);
            TxBoxList.Add(Tx_Count_6);
            TxBoxList.Add(Tx_Count_7);
            TxBoxList.Add(Total_count);
            buttonContent = new BizContent();
            this.FormClosing += OnFormClosing;
        }

        private void StartListening()
        {
            try
            {
                // 이전 리스너가 있으면 정리
                StopListening();

                // 새로운 리스너 시작
                _listener = new TcpListener(IPAddress.Any, 6068);
                _listener.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                _listener.Start();
                _isListening = true;
                _isClientConnected = false;
                Log("서버가 6068 포트에서 시작되었습니다...");

                // CancellationTokenSource 생성
                _cancellationTokenSource = new CancellationTokenSource();

                // 클라이언트 연결 대기 시작
                _listenTask = Task.Run(() => ListenForClients(_cancellationTokenSource.Token));

                // 타이머를 시작합니다.
                _timer = new System.Threading.Timer(CheckForTimeout, null, timeout, Timeout.Infinite);
            }
            catch (Exception ex)
            {
                Log("StartListening 예외 발생: " + ex.Message);
            }
        }

        private async void ListenForClients(CancellationToken cancellationToken)
        {
            try
            {
                while (_isListening && !cancellationToken.IsCancellationRequested)
                {
                    try
                    {
                        // 클라이언트 연결을 비동기로 대기합니다.
                        _client = await _listener.AcceptTcpClientAsync();
                        Log("6068 클라이언트 연결 수락됨");
                        SendMessageToClient();
                        _clientCancellationTokenSource?.Cancel();
                        _clientCancellationTokenSource = new CancellationTokenSource();
                        // 클라이언트가 연결되면 타이머를 멈추고 상태를 갱신합니다.
                        _timer.Change(Timeout.Infinite, Timeout.Infinite);
                        _isClientConnected = true;

                        // 클라이언트와 데이터를 주고받는 작업을 처리합니다.
                        await HandleClient(_client);

                        // 클라이언트 연결이 해제되면 클라이언트 객체를 해제하고 타이머를 다시 시작합니다.
                        _isClientConnected = false;
                        _client = null;
                        _timer.Change(timeout, Timeout.Infinite);
                    }
                    catch (ObjectDisposedException)
                    {
                        Log("TcpListener가 중지되었습니다.");
                    }
                    catch (Exception ex)
                    {
                        Log("ListenForClients 예외 발생: " + ex.Message);
                    }
                }
            }
            finally
            {
                // 리스닝 작업이 종료될 때 클라이언트 연결 해제
                _client?.Close();
                Log("리스닝 작업이 종료되었습니다.");
            }
        }

        private async Task HandleClient(TcpClient client)
        {
            NetworkStream stream = client.GetStream();
            byte[] buffer = new byte[1024];
            int bytesRead;
            var keepAliveTimeout = TimeSpan.FromSeconds(70);
            var lastKeepAlive = DateTime.UtcNow;

            try
            {
                while (true)
                {
                    if (stream.DataAvailable)
                    {
                        bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                        string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                        var jsonData = JsonConvert.DeserializeObject<ReceiveData>(message);

                        if (jsonData != null && jsonData.method == "device.state.get.resp")
                        {
                            buttonContent = jsonData.respContent;
                            lastKeepAlive = DateTime.UtcNow;
                            Log("6068 받은 메시지: " + message);
                        }
                        if (jsonData != null && (jsonData.method == "device.state.autoUp"))
                        {
                            lastKeepAlive = DateTime.UtcNow;
                            Log("6068 받은 메시지: " + message);
                            if (jsonData.bizContent.DI4 == 1)
                            {
                                totalCount++;
                                UpdateTotalCountBox(totalCount.ToString());

                            }
                            else if(jsonData.bizContent.AddBizContent() >= 1) 
                            {
                                buttonContent = jsonData.bizContent;
                            }
                        }
                        if (jsonData != null && jsonData.method == "device.report.keepAlive")
                        {
                            lastKeepAlive = DateTime.UtcNow;
                            Log("6068 Alive 메시지 수신");
                        }
                    }
                    if (DateTime.UtcNow - lastKeepAlive > keepAliveTimeout)
                    {
                        Log("클라이언트의 Keep-Alive 타임아웃 발생, 연결 끊어짐");
                        break;
                    }
                }
                Log($"클라이언트 연결 끊어짐");
            }
            catch (Exception e)
            {
                Log("HandleClient 예외 발생: " + e.Message);
            }
            finally
            {
                stream.Close();
                client.Close();
                Log("클라이언트 연결 해제됨");

                // 클라이언트 연결 해제 시 새로운 연결을 대기
                _isClientConnected = false;
                StartListening();
            }
        }
        private void SendMessageToClient()
        {
            Thread.Sleep(1000);
            if (_client != null && _client.Connected)
            {
                JObject json = new JObject();
                JArray bizContent = new JArray();
                json.Add("msgId", "20240814023914916323");
                json.Add("sn", "w221413s00400029eab2");
                json.Add("method", "device.state.get");
                bizContent.Add("DI1");
                bizContent.Add("DI2");
                bizContent.Add("DI3");
                json.Add("bizContent", bizContent);
                string data = json.ToString();
                NetworkStream stream = _client.GetStream();
                byte[] responseBytes = Encoding.UTF8.GetBytes(data);
                stream.WriteAsync(responseBytes, 0, responseBytes.Length);
            }
            else
            {
                Log("클라이언트가 연결되어 있지 않음.");
            }
        }
        private void UpdateTotalCountBox(string text)
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => Total_count.Text = text));
            }
            else
            {
                Total_count.Text = text;
            }
        }

        private void CheckForTimeout(object state)
        {
            if (!_isClientConnected && _isListening)
            {
                Log("타임아웃 발생: 포트를 닫았다가 다시 엽니다.");
                RestartListening();
            }
        }

        private void RestartListening()
        {
            _isListening = false;

            // 현재 작업을 취소하고 종료 대기
            _cancellationTokenSource?.Cancel();
            _listenTask?.Wait();

            StopListening();

            // 새로운 리스닝 시작
            StartListening();
        }

        private void StopListening()
        {
            _isListening = false;
            try
            {
                _listener?.Stop();
                _listener = null;
                _cancellationTokenSource?.Cancel();
                _cancellationTokenSource?.Dispose();
                _cancellationTokenSource = null;
                _clientCancellationTokenSource?.Cancel();
                _clientCancellationTokenSource?.Dispose();
                _clientCancellationTokenSource = null;
                Log("서버가 중지되었습니다...");
            }
            catch (Exception ex)
            {
                Log("StopListening 예외 발생: " + ex.Message);
            }
        }

        private void Log(string message)
        {
            Debug.WriteLine($"{DateTime.Now}: " + message);
        }
        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            // 폼이 닫힐 때 리소스 정리
            StopListening();
            _timer?.Dispose();
            _clientCancellationTokenSource?.Cancel();
            _clientCancellationTokenSource?.Dispose();
            Log("폼이 종료되었습니다.");
        }

        public class ReceiveData
        {
            public string msgId { get; set; }
            public string sn { get; set; }
            public string method { get; set; }
            public BizContent bizContent { get; set; }
            public BizContent respContent { get; set; }

        }

        public class BizContent
        {
            public int DI1 { get; set; }
            public int DI2 { get; set; }
            public int DI3 { get; set; }
            public int DI4 { get; set; }
            public BizContent()
            {
                DI1 = 0;
                DI2 = 0;
                DI3 = 0;
                DI4 = 0;
            }
            public int AddBizContent()
            {
                return this.DI1 + this.DI2 + this.DI3;
            }
        }

        private void Sensor3_Load(object sender, EventArgs e)
        {

        }
    }
}
