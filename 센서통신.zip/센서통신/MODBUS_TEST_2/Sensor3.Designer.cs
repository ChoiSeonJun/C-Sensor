﻿namespace MODBUS_TEST_2
{
    partial class Sensor3
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.label9 = new System.Windows.Forms.Label();
            this.Total_count = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.Tx_Count_7 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.Tx_Count_6 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.Tx_Count_5 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("굴림", 20F);
            this.label9.Location = new System.Drawing.Point(396, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(129, 27);
            this.label9.TabIndex = 16;
            this.label9.Text = "총 생산량";
            // 
            // Total_count
            // 
            this.Total_count.Font = new System.Drawing.Font("굴림", 15F);
            this.Total_count.Location = new System.Drawing.Point(400, 80);
            this.Total_count.Name = "Total_count";
            this.Total_count.ReadOnly = true;
            this.Total_count.Size = new System.Drawing.Size(120, 30);
            this.Total_count.TabIndex = 24;
            this.Total_count.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("굴림", 18F);
            this.label10.Location = new System.Drawing.Point(425, 45);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 24);
            this.label10.TabIndex = 20;
            this.label10.Text = "Count";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("굴림", 20F);
            this.label11.Location = new System.Drawing.Point(278, 10);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 27);
            this.label11.TabIndex = 15;
            this.label11.Text = "TYPE 7";
            // 
            // Tx_Count_7
            // 
            this.Tx_Count_7.Font = new System.Drawing.Font("굴림", 15F);
            this.Tx_Count_7.Location = new System.Drawing.Point(270, 80);
            this.Tx_Count_7.Name = "Tx_Count_7";
            this.Tx_Count_7.ReadOnly = true;
            this.Tx_Count_7.Size = new System.Drawing.Size(120, 30);
            this.Tx_Count_7.TabIndex = 23;
            this.Tx_Count_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("굴림", 18F);
            this.label12.Location = new System.Drawing.Point(295, 45);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 24);
            this.label12.TabIndex = 19;
            this.label12.Text = "Count";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("굴림", 20F);
            this.label13.Location = new System.Drawing.Point(148, 10);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(104, 27);
            this.label13.TabIndex = 14;
            this.label13.Text = "TYPE 6";
            // 
            // Tx_Count_6
            // 
            this.Tx_Count_6.Font = new System.Drawing.Font("굴림", 15F);
            this.Tx_Count_6.Location = new System.Drawing.Point(140, 80);
            this.Tx_Count_6.Name = "Tx_Count_6";
            this.Tx_Count_6.ReadOnly = true;
            this.Tx_Count_6.Size = new System.Drawing.Size(120, 30);
            this.Tx_Count_6.TabIndex = 22;
            this.Tx_Count_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("굴림", 18F);
            this.label14.Location = new System.Drawing.Point(165, 45);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 24);
            this.label14.TabIndex = 18;
            this.label14.Text = "Count";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("굴림", 20F);
            this.label15.Location = new System.Drawing.Point(18, 10);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(104, 27);
            this.label15.TabIndex = 13;
            this.label15.Text = "TYPE 5";
            // 
            // Tx_Count_5
            // 
            this.Tx_Count_5.Font = new System.Drawing.Font("굴림", 15F);
            this.Tx_Count_5.Location = new System.Drawing.Point(10, 80);
            this.Tx_Count_5.Name = "Tx_Count_5";
            this.Tx_Count_5.ReadOnly = true;
            this.Tx_Count_5.Size = new System.Drawing.Size(120, 30);
            this.Tx_Count_5.TabIndex = 21;
            this.Tx_Count_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("굴림", 18F);
            this.label16.Location = new System.Drawing.Point(35, 45);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 24);
            this.label16.TabIndex = 17;
            this.label16.Text = "Count";
            // 
            // Sensor3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(530, 116);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Total_count);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Tx_Count_7);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.Tx_Count_6);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.Tx_Count_5);
            this.Controls.Add(this.label16);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Sensor3";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Sensor3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.TextBox Total_count;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.TextBox Tx_Count_7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        public System.Windows.Forms.TextBox Tx_Count_6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        public System.Windows.Forms.TextBox Tx_Count_5;
        private System.Windows.Forms.Label label16;
    }
}
