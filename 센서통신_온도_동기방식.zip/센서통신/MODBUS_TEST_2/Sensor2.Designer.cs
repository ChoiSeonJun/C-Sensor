﻿namespace MODBUS_TEST_2
{
    partial class Sensor2
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.Tx_Count_1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Tx_Count_2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Tx_Count_3 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Tx_Count_4 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // timer2
            // 
            this.timer2.Interval = 150;
            // 
            // Tx_Count_1
            // 
            this.Tx_Count_1.Font = new System.Drawing.Font("굴림", 15F);
            this.Tx_Count_1.Location = new System.Drawing.Point(10, 80);
            this.Tx_Count_1.Name = "Tx_Count_1";
            this.Tx_Count_1.ReadOnly = true;
            this.Tx_Count_1.Size = new System.Drawing.Size(120, 30);
            this.Tx_Count_1.TabIndex = 9;
            this.Tx_Count_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 20F);
            this.label1.Location = new System.Drawing.Point(11, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 27);
            this.label1.TabIndex = 1;
            this.label1.Text = "device 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 20F);
            this.label2.Location = new System.Drawing.Point(141, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 27);
            this.label2.TabIndex = 2;
            this.label2.Text = "device 2";
            this.label2.Visible = false;
            // 
            // Tx_Count_2
            // 
            this.Tx_Count_2.Font = new System.Drawing.Font("굴림", 15F);
            this.Tx_Count_2.Location = new System.Drawing.Point(140, 80);
            this.Tx_Count_2.Name = "Tx_Count_2";
            this.Tx_Count_2.ReadOnly = true;
            this.Tx_Count_2.Size = new System.Drawing.Size(120, 30);
            this.Tx_Count_2.TabIndex = 10;
            this.Tx_Count_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Tx_Count_2.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 18F);
            this.label6.Location = new System.Drawing.Point(167, 45);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 24);
            this.label6.TabIndex = 6;
            this.label6.Text = "온 도";
            this.label6.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 20F);
            this.label3.Location = new System.Drawing.Point(271, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 27);
            this.label3.TabIndex = 3;
            this.label3.Text = "device 3";
            this.label3.Visible = false;
            // 
            // Tx_Count_3
            // 
            this.Tx_Count_3.Font = new System.Drawing.Font("굴림", 15F);
            this.Tx_Count_3.Location = new System.Drawing.Point(270, 80);
            this.Tx_Count_3.Name = "Tx_Count_3";
            this.Tx_Count_3.ReadOnly = true;
            this.Tx_Count_3.Size = new System.Drawing.Size(120, 30);
            this.Tx_Count_3.TabIndex = 11;
            this.Tx_Count_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Tx_Count_3.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("굴림", 18F);
            this.label7.Location = new System.Drawing.Point(297, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 24);
            this.label7.TabIndex = 7;
            this.label7.Text = "온 도";
            this.label7.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 20F);
            this.label4.Location = new System.Drawing.Point(401, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 27);
            this.label4.TabIndex = 4;
            this.label4.Text = "device 4";
            this.label4.Visible = false;
            // 
            // Tx_Count_4
            // 
            this.Tx_Count_4.Font = new System.Drawing.Font("굴림", 15F);
            this.Tx_Count_4.Location = new System.Drawing.Point(400, 80);
            this.Tx_Count_4.Name = "Tx_Count_4";
            this.Tx_Count_4.ReadOnly = true;
            this.Tx_Count_4.Size = new System.Drawing.Size(120, 30);
            this.Tx_Count_4.TabIndex = 12;
            this.Tx_Count_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Tx_Count_4.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("굴림", 18F);
            this.label8.Location = new System.Drawing.Point(427, 45);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 24);
            this.label8.TabIndex = 8;
            this.label8.Text = "온 도";
            this.label8.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("굴림", 18F);
            this.label5.Location = new System.Drawing.Point(37, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 24);
            this.label5.TabIndex = 5;
            this.label5.Text = "온 도";
            // 
            // Sensor2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(530, 116);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Tx_Count_4);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Tx_Count_3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Tx_Count_2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Tx_Count_1);
            this.Controls.Add(this.label5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Sensor2";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Sensor2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox Tx_Count_1;
        public System.Windows.Forms.Timer timer1;
        public System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox Tx_Count_2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox Tx_Count_3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox Tx_Count_4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
    }
}
