﻿using JF_SENSOR_DATA;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MODBUS_TEST_2
{
    public partial class MainForm : Form
    {
        Sensor1 sen1 = new Sensor1();
/*        Sensor2 sen2 = new Sensor2();
*/        Sensor3 sen3 = new Sensor3();
        DBHelper helper = new DBHelper();
        int[] count = new int[7];
        BizContentSave bizContentSave = new BizContentSave();
        public MainForm()
        {
            InitializeComponent();
            LodingData();
            Sensor1_Load();
            /*            Sensor2_Load();*/
            Sensor3_Load();

        }

        private void Sensor1_Load()
        {
            sen1.TopLevel = false;
            this.Controls.Add(sen1);
            sen1.StartPosition = FormStartPosition.Manual;
            sen1.Location = new Point(17, 10);
            sen1.Show();            
        }
        private void Sensor3_Load()
        {
            sen3.TopLevel = false;
            this.Controls.Add(sen3);
            sen3.StartPosition = FormStartPosition.Manual;
            sen3.Total_count.TextChanged += CheckButtonContent;
            sen3.Location = new Point(17, 130);
            sen3.Show();
        }
/*        private void Sensor2_Load()
        {
            sen2.TopLevel = false;
            this.Controls.Add(sen2);
            sen2.StartPosition = FormStartPosition.Manual;
            sen2.Location = new Point(17, 250);
            sen2.Show();
        }*/


        /*private void timer1_Tick(object sender, EventArgs e)
        {

            helper.Disconnect();

        }

        private void Tx_TimeSet_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsDigit(e.KeyChar) || e.KeyChar == Convert.ToChar(Keys.Back)))
            {
                e.Handled = true;
            }
        }


        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Enabled = false;
        }
        */
        private void LodingData()
        {
            count = helper.CountSelect();
            int j = 0;
            int totalCount = 0;
            foreach(int i in count)
            {
                totalCount += i;
                if(j > 3)
                {
                    sen3.TxBoxList[j-4].Text = i.ToString();
                }
                else
                {
                    sen1.TxBoxList[j].Text = i.ToString();
                }
                j++;
            }
            sen3.Total_count.Text = totalCount.ToString();
            sen3.totalCount = totalCount;
            // sen2.timer.enable =true;랑 timer의 interval을 main box의 value로 조정
        }

        private void CheckButtonContent(object sender, EventArgs e)
        {
            Log($"total Count 변경");
            bizContentSave.AddBizContent(sen1.buttonContent, sen3.buttonContent);
            int index = bizContentSave.CheckBtnIndex();
            helper.insertCount(index);
            Console.WriteLine("index : "+index.ToString());
            count[index-1]++;
            if (index > 4)
            {
                sen3.TxBoxList[index-5].Text = count[index-1].ToString();
            }
            else if(index != 0)
            {
                sen1.TxBoxList[index-1].Text = count[index-1].ToString();
            }

            //버튼 여러개 누렀을 때 bizContent 비우기
            /*bizContentSave = bizContentSave.CheckBizContent(sen1.buttonContent, sen3.buttonContent);
            Console.WriteLine($"main type 1 {bizContentSave.DI1}");
            Console.WriteLine($"main type 2 {bizContentSave.DI2}");
            Console.WriteLine($"main type 3 {bizContentSave.DI3}");
            Console.WriteLine($"main type 4 {bizContentSave.DI4}");
            Console.WriteLine($"main type 5 {bizContentSave.DI5}");
            Console.WriteLine($"main type 6 {bizContentSave.DI6}");
            Console.WriteLine($"main type 7 {bizContentSave.DI7}");*/
        }
        private void Log(string message)
        {
            // 디버그 출력 (로그 파일 등)
            Debug.WriteLine($"{DateTime.Now}: {message}");
        }
        internal class BizContentSave
        {
            public int DI1;
            public int DI2;
            public int DI3;
            public int DI4;
            public int DI5;
            public int DI6;
            public int DI7;

            public BizContentSave()
            {
                DI1 = 0;
                DI2 = 0;
                DI3 = 0;
                DI4 = 0;
                DI5 = 0;
                DI6 = 0;
                DI7 = 0;
            }
            public int CheckBtnIndex()
            {
                int index = DI1 ==1 ? 1 : DI2 == 1 ? 2: DI3 == 1? 3 : DI4 == 1? 4: DI5 ==1 ? 5: DI6 ==1 ? 6: DI7 ==1? 7 : 0;
                return index;
            }
            public void AddBizContent(Sensor1.BizContent bizContent1, Sensor3.BizContent bizContent2)
            {
                DI1 = bizContent1.DI1; 
                DI2 = bizContent1.DI2; 
                DI3 = bizContent1.DI3; 
                DI4 = bizContent1.DI4;
                DI5 = bizContent2.DI1;
                DI6 = bizContent2.DI2;
                DI7 = bizContent2.DI3;
            }
            public BizContentSave CheckBizContent(Sensor1.BizContent newButton1, Sensor3.BizContent newButton2)
            {
                int check = newButton1.DI1 + newButton1.DI2 + newButton1.DI3 + newButton1.DI4 + newButton2.DI1 + newButton2.DI2 + newButton2.DI3;
                if(check >1) 
                {
                    if (newButton1.DI1 == 1 && this.DI1 == 0)
                    {
                        this.DI1 = 1;
                        this.DI2 = 0;
                        this.DI3 = 0;
                        this.DI4 = 0;
                        this.DI5 = 0;
                        this.DI6 = 0;
                        this.DI7 = 0;
                    }
                    else if (newButton1.DI2 == 1 && this.DI2 == 0)
                    {
                        this.DI1 = 0;
                        this.DI2 = 1;
                        this.DI3 = 0;
                        this.DI4 = 0;
                        this.DI5 = 0;
                        this.DI6 = 0;
                        this.DI7 = 0;
                    }
                    else if (newButton1.DI3 == 1 && this.DI3 == 0)
                    {
                        this.DI1 = 0;
                        this.DI2 = 0;
                        this.DI3 = 1;
                        this.DI4 = 0;
                        this.DI5 = 0;
                        this.DI6 = 0;
                        this.DI7 = 0;
                    }
                    else if (newButton1.DI4 == 1 && this.DI4 == 0)
                    {
                        this.DI1 = 0;
                        this.DI2 = 0;
                        this.DI3 = 0;
                        this.DI4 = 1;
                        this.DI5 = 0;
                        this.DI6 = 0;
                        this.DI7 = 0;
                    }
                    else if (newButton2.DI1 == 1 && this.DI5 == 0)
                    {
                        this.DI1 = 0;
                        this.DI2 = 0;
                        this.DI3 = 0;
                        this.DI4 = 0;
                        this.DI5 = 1;
                        this.DI6 = 0;
                        this.DI7 = 0;
                    }
                    else if (newButton2.DI2 == 1 && this.DI6 == 0)
                    {
                        this.DI1 = 0;
                        this.DI2 = 0;
                        this.DI3 = 0;
                        this.DI4 = 0;
                        this.DI5 = 0;
                        this.DI6 = 1;
                        this.DI7 = 0;
                    }
                    else if (newButton2.DI3 == 1 && this.DI7 == 0)
                    {
                        this.DI1 = 0;
                        this.DI2 = 0;
                        this.DI3 = 0;
                        this.DI4 = 0;
                        this.DI5 = 0;
                        this.DI6 = 0;
                        this.DI7 = 1;
                    }

                }
                return this;
            }
        }
    }
}
