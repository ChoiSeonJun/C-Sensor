﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using System.Diagnostics;
using System.Threading;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Reflection;
using MySqlX.XDevAPI.Common;

namespace MODBUS_TEST_2
{
    public partial class Sensor2 : Form
    {
        // USR이 서버, PC가 USR로 접속
        Socket Sensor_Sock;
        AsyncObject obj = new AsyncObject(99999);   // 소켓 크기 설정
        private bool reconnecting = false;
        private readonly object lockObject = new object();
        public List<float> temValues = new List<float>();
        private int reconnectAttempts = 0;
        private const int maxReconnectAttempts = 5;
        private const int reconnectDelay = 5000; // 5초 지연 후 재연결 시도
        private string serverIp = "10.10.61.111";
        private int port = 8899;

        // 폼이 로드될때 실행되는 생성자
        public Sensor2()
        {
            InitializeComponent();  // UI컴포넌트 초기화 => 자동으로 생성되는것임. 건드릴필요 없음
            SocketSet();            // 소켓 설정 수행
            ConnServer();           // 서버에 연결
        }

        // 소켓 객체 생성 및 설정 => 기본으로 선언해줘야함
        private void SocketSet()
        {
            // 기본으로 선언해줘야하는 "소켓 생성" 코드 (처음에는 닫혀있으니 이렇게 선언해줘야한다)
            Sensor_Sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        }

        // 서버 연결
        private void ConnServer()
        {
            string serverip = serverIp;
            int serverport = port;

            try
            {
                // 기존에 이미 연결이 되어있다면 연결 끊기     
                if (Sensor_Sock != null && Sensor_Sock.Connected)
                {
                    Sensor_Sock.Shutdown(SocketShutdown.Both);
                    Sensor_Sock.Close();
                }

                // 서버의 IP 주소를 설정하고 엔드포인트 생성
                IPAddress serverAddr = IPAddress.Parse($"{serverip}");  //IPAddress.Parse를 이용해 IP를 담을 수 있는 형식의 함수에 저장
                IPEndPoint clientEP = new IPEndPoint(serverAddr, serverport); // 위에서 담은 IP와 Port를 저장

                // 다시 "소켓 생성"
                Sensor_Sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                //비동기 연결 시작 (연결을 시도한 후 결과를 기다리지 않고도 다른 작업을 할 수 있도록 비동기 연결 필수)
                Sensor_Sock.BeginConnect(clientEP, new AsyncCallback(ConnectCallback), Sensor_Sock); //ConnectCallback함수 실행
                Log($"Sen 1 서버 {serverip}:{serverport}에 연결 시도 중");
            }
            catch (Exception ex)
            {
                Log($"Sen 1 연결 오류: {ex}");
                Reconnect();
            }
            finally
            {
                timer1.Enabled = true;
                timer2.Enabled = true;
            }
        }


        // 서버 연결이 완료되었을 때 실행되는 콜백 함수 (연결 잘 안됐을때 연결 재시도하기 위함)
        void ConnectCallback(IAsyncResult ar)
        {
            try
            {
                // 비동기 작업에서 소켓 객체 가져오기
                Socket client = (Socket)ar.AsyncState;

                // 소켓이 없을때 연결 재시도
                if (client == null)
                {
                    Log("Sen 1 소켓이 null입니다.");
                    Reconnect();
                    return;
                }

                // 소켓연결 안됐을때 연결 재시도
                if (!client.Connected)
                {
                    Log("Sen 1 소켓이 연결되지 않았습니다.");
                    Reconnect();
                    return;
                }

                // 연결 완료처리
                client.EndConnect(ar);

                //연결 완료되었다면 비동기 데이터 수신 시작
                if (client.Connected)
                {
                    obj.WorkingSocket = Sensor_Sock;
                    Log("Sen 1 서버에 연결됨.");

                    // 비동기 데이터 수신(Receive) 시작
                    Sensor_Sock.BeginReceive(obj.Buffer, 0, obj.BufferSize, 0, DataReceived, obj); //DataReceived함수 실행
                }
                else
                {
                    Log("Sen 1 서버에 연결 실패.");
                    Reconnect();
                }
            }
            //예외처리
            catch (SocketException ex)
            {
                Log($"Sen 1 ConnectCallback 오류: {ex.Message}");
                Reconnect();
            }
            catch (ObjectDisposedException ex)
            {
                Log($"Sen 1 ConnectCallback 오류: {ex.Message}");
                Reconnect();
            }
            catch (Exception ex)
            {
                Log($"Sen 1 예기치 않은 ConnectCallback 오류: {ex}");
                Reconnect();
            }
        }

        // 비동기 데이터 수신 객체 정의
        public class AsyncObject
        {
            public byte[] Buffer;           // 데이터를 저장할 바이트 배열(거의 이 버퍼떄문에 AsyncObject를 선언한것)
            public Socket WorkingSocket;    // 연결된 소켓 객체
            public readonly int BufferSize  // 버퍼 크기

            public AsyncObject(int bufferSize)
            {
                BufferSize = bufferSize;
                Buffer = new byte[BufferSize];
            }

            // 버퍼 초기화 (기존 데이터 삭제)
            public void ClearBuffer()
            {
                Array.Clear(Buffer, 0, BufferSize);
            }
        }

        void DataReceived(IAsyncResult ar)
        {
            try
            {
                // 비동기 데이터 수신 객체 정의하는 함수 호출
                AsyncObject obj = (AsyncObject)ar.AsyncState;   

                // 소켓 연결 상태 확인
                if (obj.WorkingSocket == null || !obj.WorkingSocket.Connected)
                {
                    Log("Sen 1 소켓이 연결되지 않았습니다.");
                    Reconnect(); // 연결되지 않았다면 재연결 시도
                    return;
                }

                // 수신된 데이터 크기 확인
                int received = obj.WorkingSocket.EndReceive(ar);
                // 리시브받을 버퍼 정의
                byte[] buffer = new byte[received];
                // 실제로 수신한 데이터 크기(received)만큼 새로운 buffer에 복사해서 사용
                Array.Copy(obj.Buffer, 0, buffer, 0, received);

                // 로그에 바이트 데이터를 16진수 문자열로 변환하여 출력
                Log($"Sen 1 데이터 받음 - 수신된 데이터: {received}, 버퍼: {BitConverter.ToString(buffer)}");
                //수신된 데이터 처리
                ProcessData(buffer);

                Log($"Sen 1 데이터수신 완료.");

                // 콜백 함수로 자기 자신을 다시 호출하여 지속적인 데이터 수신
                obj.WorkingSocket.BeginReceive(obj.Buffer, 0, obj.BufferSize, 0, DataReceived, obj);
            }
            catch (ObjectDisposedException)
            {
                // 소켓이 폐기되었음, 아무것도 수행하지 않거나 이벤트를 로깅합니다.
                Log("Sen 1 소켓이 폐기되었습니다.");
            }
            catch (Exception ex)
            {
                Log($"Sen 1 DataReceived 오류: {ex}");
                Reconnect();
            }
        }

        // 소켓 재연결
        private void Reconnect()
        {
            lock (lockObject)
            {
                if (reconnecting || reconnectAttempts >= maxReconnectAttempts)
                {
                    Log("Sen 1 최대 재연결 시도 횟수에 도달했거나 이미 재연결 중입니다.");
                    return;
                }

                reconnecting = true;
                reconnectAttempts++;
                Log($"Sen 1 재연결 중... 시도 #{reconnectAttempts}");

                try
                {
                    if (Sensor_Sock != null)
                    {
                        Sensor_Sock.Close();
                        Sensor_Sock = null;
                    }

                    // 새 소켓 생성
                    SocketSet();
                    Thread.Sleep(reconnectDelay); // 재연결 전 지연 추가
                    ConnServer();
                }
                catch (Exception ex)
                {
                    Log($"Sen 1 재연결 오류: {ex}");
                }
                finally
                {
                    reconnecting = false;
                }
            }
        }

        public byte[] HexToByte(string strHex)
        {
            byte[] bytes = new byte[strHex.Length / 2];
            for (int count = 0; count < strHex.Length; count += 2)
            {
                bytes[count / 2] = Convert.ToByte(strHex.Substring(count, 2), 16);
            }
            return bytes;
        }

        // 바이트형으로 받은걸 헥사코드로 변환
        public string ByteToHex(byte[] hex)
        {
            StringBuilder result = new StringBuilder(hex.Length * 2);
            foreach (byte b in hex)
            {
                result.Append(b.ToString("x2").ToUpper());
            }
            return result.ToString();
        }

        public string ConvertBufferToString(string msg)
        {
            Log($"Sen 1 데이터 수신: {msg}");

            if (msg == null || msg.Length < 34)
            {
                throw new ArgumentOutOfRangeException(nameof(msg), "Sen 1 입력 문자열이 너무 짧습니다.");
            }
            if (msg.Length > 34)
            {
                throw new ArgumentOutOfRangeException(nameof(msg), "Sen 1 입력 문자열이 깁니다.");
            }
            string con = msg.Substring(6, 24);
            Log($"msg 변환 : {con}");
            return con;
        }

        public float HextoFloat(string num)  //사용하는곳이 없는데 필요한가..?
        {
            int intRep = int.Parse(num, NumberStyles.AllowHexSpecifier); // 16진수 문자열을 정수로 파싱
            float f = intRep;// 실제 값으로 변환하기 위해 10으로 나누기
            return f;
        }
        public List<string> SplitString(string str)
        {
            List<string> result = new List<string>();
            for (int i = 0; i < str.Length / 4; i++)
            {
                result.Add(str.Substring(i * 4, 4));
                Log($"{result[i]}");
            }
            return result;
        }
        /*측정 값의 최대 최소 범위 같이 입력*/
        public float ConvertElecToTem(float value, float min, float max)
        {
            float sub = max - min;
            float result = (value - 4.0f) / 16.0f * sub + min;
            return result;
        }
        public float ConvertVoltToTem(float value, float min, float max)
        {
            float sub = max - min;
            float result = (value - 1.0f) / 4.0f * sub + min;
            return result;
        }
        void ProcessData(byte[] buffer)
        {
            // 바이트 배열을 16진수 문자열(헥사코드)로 변환
            List<string> responseMsg = SplitString(ConvertBufferToString(ByteToHex(buffer))); //ByteToHex 코드 함수 호출
            int i = 0;
            foreach (var str in responseMsg)
            {
                // ConverTElecToTem :전기적 신호 값을 온도로 변환하는 함수 (전기 신호 값, 최소값, 최대값)
                // TemValues.Add(..) 변환된 온도값을 List<float> 에 추가 (전역변수)
                temValues.Add(ConvertElecToTem(20, 100, 255)); 
                Log($"{temValues[i]}"); // 변환된 온도값 로그 출력
                i++;
            }
        }

        // CRC (메뉴얼에 따른 함수)
        private static ushort CalculateCRC(byte[] data, int length)
        {
            ushort crc = 0xFFFF;
            for (int i = 0; i < length; i++)
            {
                crc ^= (ushort)(data[i] & 0xFF);

                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 0x0001) != 0)
                    {
                        crc >>= 1;
                        crc ^= 0xA001;
                    }
                    else
                    {
                        crc >>= 1;
                    }
                }
            }
            return crc;
        }

        // 몇초마다 자동으로 실행되는 스레드형식의 코드(스레드는 아니고 Timer)
        private void timer2_Tick(object sender, EventArgs e)
        {
            // 소켓 연결 상태 확인
            if (Sensor_Sock == null || !Sensor_Sock.Connected)
            {
                Log("타이머가 동작 중인데 소켓이 연결되지 않았습니다. 재연결 시도.");
                Reconnect();
                return;
            }

            // 데이터 전송을 위한 바이트 배열 정의
            List<byte[]> sendDataList = new List<byte[]>
             {
               new byte[] { 0x01, 0x04, 0x00, 0x00, 0x00, 0x04}
               // 0x01: 디바이스 주소
               // 0x04: 기능코드 명령어 (센서 데이터를 읽어옴)
               // 0x00, 0x00: 시작 주소 (레지스터 오프셋)
               // 0x00, 0x04: 읽을 레지스터 개수 (4개)
            };
            foreach (var sendData in sendDataList)
            {
                // CRC 계산
                ushort crc = CalculateCRC(sendData, sendData.Length);
                byte crcLow = (byte)(crc & 0xFF);
                byte crcHigh = (byte)((crc >> 8) & 0xFF);

                // CRC를 추가한 전송용 데이터 배열 생성
                byte[] sendDataWithCRC = new byte[sendData.Length + 2]; // 기존 데이터 + CRC(2바이트) 를 담을 배열 선언
                Array.Copy(sendData, 0, sendDataWithCRC, 0, sendData.Length); // 원본데이터 복사
                sendDataWithCRC[sendData.Length] = crcLow;  // 배열에 기존 데이터 + CRC의 하위 바이트 추가
                sendDataWithCRC[sendData.Length + 1] = crcHigh; // 배열에 (기존 데이터 + CRC의 하위 바이트) + CRC의 상위 바이트 추가

                // 변환된 데이터 로그 출력
                string sendDataString = BitConverter.ToString(sendDataWithCRC);
                Log($"변환 데이터01: {sendDataString}");

                try
                {
                    // 데이터 전송
                    Sensor_Sock.Send(sendDataWithCRC);

                    // 데이터 수신 대기 시작
                    Sensor_Sock.BeginReceive(obj.Buffer, 0, obj.BufferSize, 0, DataReceived, obj);
                    Thread.Sleep(200); // 대기 지연 추가 (현재는 비동기방식이 아닌 동기방식. 때문에 대기시간동안 UI가 멈춤)
                }
                catch (Exception ex)
                {
                    // 예외 처리
                    Log($"데이터 전송 오류: {ex}");
                    Reconnect();
                }
                finally
                {
                    // 타이머1 활성화
                    timer1.Enabled = true;
                }
            }
        }


        private void Log(string message)
        {
            // 디버그 출력 (파일이나 다른 목적지에 로그 기록)
            Debug.WriteLine($"{DateTime.Now}: {message}");
        }

        private void Sensor2_Load(object sender, EventArgs e)
        {

        }
    }
}
